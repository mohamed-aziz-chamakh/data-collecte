# arduino-esp32-SOLO

These libraries allow you to compile arduino-esp32 applications for the ESP32-SOLO single core MCU.  Just replace the files in your esp32 directory with the included files.
The libraries are only compiled for release versions of arduino-esp32.  Checkout the commit corresponding to your version in Arduino IDE boards manager.

[Tasmota](https://github.com/tasmota/platform-espressif32/releases) has started providing releases supporting the SOLO, so I will recommend using those packages, along with Platform.io in the future.
